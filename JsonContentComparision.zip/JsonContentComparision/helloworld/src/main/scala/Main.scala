import java.io.{File, FileNotFoundException}
import java.net.URL
import java.net.URI
import java.nio.file.Paths
import ujson.Value.Value
import com.google.common.io.Resources
import scala.io.{BufferedSource, Source}

object Main extends App {

  def getListOfJsonFileNameAndFilePath(
    dir: String
  ): (Set[String], Set[String]) = {
    val file = new File(dir)
    file.listFiles
      .map(_.getName)
      .toSet -> file.listFiles
      .map(_.getPath)
      .toSet
  }

  def getJsonContent(dir: String): Value = {
    var bufferSource: BufferedSource = null
    try {
      bufferSource = Source.fromFile(dir)
      val jsonContent: String = bufferSource.getLines.mkString
      val data = ujson.read(jsonContent)
      data
    } catch {
      case e1: FileNotFoundException =>
        println(s"$dir was not found, please chcek and try again")
        ujson.read(s"$dir was not found, please chcek and try again")
    } finally {
      if (bufferSource != null)
        bufferSource.close()
    }
  }

  val featureFilePath =
    getClass.getClassLoader.getResource("feature_file").getPath
  val partner_ConfigPath =
    getClass.getClassLoader.getResource("partner_config").getPath

  val filesFromFeatureFileFolder = getListOfJsonFileNameAndFilePath(
    featureFilePath
  )
  val filesFromPartner_ConfigFolder = getListOfJsonFileNameAndFilePath(
    partner_ConfigPath
  )

  if (filesFromFeatureFileFolder._1 == filesFromPartner_ConfigFolder._1) {

    val comparison: Map[String, String] =
      filesFromFeatureFileFolder._1.foldLeft(Map[String, String]()) {
        case (comparisionLogs: Map[String, String], filePath: String) =>
          val jsonContentFromFeature = getJsonContent(
            filesFromFeatureFileFolder._2.find(x => x.contains(filePath)).get
          )
          val jsonContentFromPartner_Config = getJsonContent(
            filesFromPartner_ConfigFolder._2.find(x => x.contains(filePath)).get
          )
          if (jsonContentFromFeature == jsonContentFromPartner_Config) {
            comparisionLogs
          } else {
            comparisionLogs + (filesFromFeatureFileFolder._2
              .find(x => x.contains(filePath))
              .get -> "This File Has discrepency")
          }
      }
    println(comparison)
  } else {
    val sdsdfvsd: URL =
      Resources.getResource("crosswalks/areaOfExpertise/uhc.json")

    val folderInfo = Paths
      .get(new URI("crosswalks/areaOfExpertise/uhc.json").getPath())
    println(sdsdfvsd.getFile)
    println("crosswalks/areaOfExpertise/uhc.json".contains("areaOfExpertise"))
    println(folderInfo.getFileName.toString)
    println(folderInfo.getName(2).toString)
    println(
      "crosswalks/areaOfExpertise/bsbc.json"
        .split("/")
        .toList
        .lastOption
        .getOrElse("nofile.json")
        .split("/.")
        .toList
        .headOption
        .getOrElse("nofile")
    )
    println("No. of Config files do not match")
  }

}
