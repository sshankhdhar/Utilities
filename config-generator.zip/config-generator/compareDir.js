import * as fs from "fs";
import pkg from "lodash";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const configrationList = require("./feature.json");

const { transform, isEqual, isObject } = pkg;

// This is STEP-3
// Only to be executed after storeConfigs.js has been run twice with two different tenants
// Edit the directory names below to compare files

// ONLY MAKE CHANGES TO THIS
var dir2 = "./production";
var dir1 = "./productionWithNCT2";
// *-------------------------------------------------------------------------------------*

function getDifference(object, base) {
  return transform(object, (result, value, key) => {
    if (!isEqual(value, base[key])) {
      result[key] =
        isObject(value) && isObject(base[key])
          ? getDifference(value, base[key])
          : value;
    }
  });
}

const featureParams = [];
configrationList.forEach((config) => {
  const query = config.parameters;
  if (config.parameters.partner) {
    featureParams.push(query);
  }
});

const compare = () => {
  for (let index = 1; index < featureParams.length + 1; index++) {
    const path_dir1 = dir1 + "/" + index + ".txt";
    const path_dir2 = dir2 + "/" + index + ".txt";

    var json1 = JSON.parse(fs.readFileSync(path_dir1));
    var json2 = JSON.parse(fs.readFileSync(path_dir2));

    if (isEqual(json1, json2) === false) {
      console.log(index + " has a difference");
      console.log("Parameters: " + JSON.stringify(featureParams[index - 1]));
      console.log(getDifference(json1, json2));
      console.log("---------------------------------------");
      fs.appendFileSync(
        "Output.txt",
        index + " has a difference" + "\n" + "Parameters: " + JSON.stringify(featureParams[index - 1]) + "\n" + JSON.stringify(getDifference(json1, json2)) + "\n" + "---------------------------------------" + "\n",
        function (err) {
          if (err) throw err;
        }
      );
    }
  }
};

compare();
