import fetch from "node-fetch";
import * as fs from "fs";

// This is STEP-2
// Only to be executed after URL.txt has been generated properly
// Edit the directory name to store configs of different tenants in different folders

// ONLY MAKE CHANGES TO THIS
var dir = "./productionWithNCT2";
// *-------------------------------------------------------------------------------------*

if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir);
}

console.log("Printing responses being received from each URL");

const createFiles = async () => {
  await Promise.all(
    fs
      .readFileSync("URL.txt", "utf-8")
      .split(/\r?\n/)
      .map(async (line, index) => {
        const path = dir + "/" + (index + 1) + ".txt";
        if (line.length !== 0) {
          if (fs.existsSync(path)) {
            fs.truncateSync(path, 0);
          }
          const response = await fetch(line);
          const responseJson = await response.json();
          console.log(responseJson);
          fs.appendFileSync(path, JSON.stringify(responseJson, null, 2));
        }
      })
  );
};

createFiles();
