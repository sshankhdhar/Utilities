import fetch from "node-fetch";
import * as fs from "fs";
import pkg from "lodash";
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const configrationList = require("./feature.json");

const { isEqual } = pkg;

// Find difference in api reponses of two tenants, one of them is stated in URL.txt other's name can be specified in line 29 & 39

function getDifference(object, base) {
  return transform(object, (result, value, key) => {
    if (!isEqual(value, base[key])) {
      result[key] =
        isObject(value) && isObject(base[key])
          ? getDifference(value, base[key])
          : value;
    }
  });
}

const featureParams = [];
configrationList.forEach((config) => {
  const query = config.parameters;
  if (config.parameters.partner) {
    featureParams.push(query);
  }
});

const findDifference = async () => {
  await Promise.all(
    fs
      .readFileSync("URL.txt", "utf-8")
      .split(/\r?\n/)
      .map(async (line, index) => {
        if (line.length !== 0) {
          const tenant1Response = await fetch(line);
          const tenant2Response = await fetch(
            line.replace("vivid-shake", "polite-fall")
          );

          const tenant1Json = await tenant1Response.json();
          const tenant2Json = await tenant2Response.json();

          if (isEqual(tenant1Json, tenant2Json) === false) {
            console.log(index + 1 + " has a difference");
            console.log("Parameters: " + JSON.stringify(featureParams[index]));
            console.log("FIELDS THAT ARE DIFFERENT ARE:");
            console.log(getDifference(tenant1Json, tenant2Json));
            console.log("URLS:");
            console.log(line);
            console.log(line.replace("vivid-shake", "polite-fall"));
            console.log("---------------------------------------");
          }
        }
      })
  );
  console.log("PROCESS COMPLETED");
};

findDifference();
