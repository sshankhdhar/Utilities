import { createRequire } from "module";
const require = createRequire(import.meta.url);
const configrationList = require("./feature.json");

import * as fs from "fs";

// This is STEP-1
// This has be executed only after feature.json has been copied properly in the feature.json file in the same directory as this file
// BaseURL can be changed

fs.openSync("./URL.txt", "w+");

// ONLY MAKE CHANGES TO THIS
const baseURL = (partner) =>
  "https://connect.werally.com/rest/partner/v2/partners/" +
  partner +
  "/configuration?";
// *-------------------------------------------------------------------------------------*

console.log(
  "*-------------------------------------------------------------------------------------*"
);
console.log("List of URLS copied in the text file are generated below:");

configrationList.forEach((config) => {
  const query = config.parameters;
  const partnerId = config.parameters.partner;
  if (config.parameters.partner) {
    delete query.partner;

    if (config.parameters.planCode) {
      query.externalPlanCode = config.parameters.planCode;
      delete query.planCode;
    }
    fs.appendFileSync(
      "URL.txt",
      baseURL(partnerId) + new URLSearchParams(query).toString() + "\n",
      function (err) {
        if (err) throw err;
      }
    );
  }
  console.log(baseURL(partnerId) + new URLSearchParams(query).toString());
});
