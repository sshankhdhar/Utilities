# config-generator

1. Store feature.json file in parent directory
2. change baseURL in generateURL.js & run "node generateURL.js" to generate list of URLs in URL.txt
3. change directoryName in storeConfigs.js & run "node storeConfigs.js" to store all URL responses from URL.txt
4. Repeat 2. & 3. to generate folders for different tenants
5. use the tenant names as directory names in compareDir.js and run "node compareDir.js" to print the differences in the json responses
