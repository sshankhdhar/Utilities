package excelToJson

import java.io.{File, FileOutputStream, PrintWriter}
import java.time.{Instant, LocalDateTime, OffsetDateTime, ZonedDateTime}
import java.util.Date

import org.bson.types.ObjectId
import org.json4s._
import org.json4s.jackson.Serialization._
//import org.json4s.nativ.Serialization
import org.apache.poi.ss.usermodel.{Cell, CellType, Row, Sheet, WorkbookFactory}
import org.json4s.jackson.Serialization

class Converter {

  implicit val formats = Serialization.formats(NoTypeHints)

  def read = {

    val c = getClass.getResource("/NewConfigurationFile.xlsx")

    println(c)

    val f = new File(c.getPath)
    val workbook = WorkbookFactory.create(f)
    val sheet: Sheet = workbook.getSheetAt(0)
    var fieldTypes = Seq.empty[String]
//    var fieldInputTypes = Seq.empty[String]
    var fieldValues = Seq.empty[Seq[String]]
    var fieldLabels = Seq.empty[String]
//    var i = 0;
    var configs = Seq.empty[Map[String, Any]]
    println(sheet.getLastRowNum)
    sheet.forEach(row => {
      row.removeCell(row.getCell(0))
      var input = Map.empty[String, String]
      var output = Map.empty[String, String]
//      println(s"last column is ${row.getLastCellNum}")
      val size = fieldTypes.size
      row.forEach(cell => {
        row.getRowNum match {
          case 1 => fieldTypes = fieldTypes.+:(cell.getStringCellValue)
//          case 2 => fieldInputTypes = fieldInputTypes.+:(cell.getStringCellValue)
          case 0 =>
            fieldLabels =
              fieldLabels.+:(Converter.toCamel(cell.getStringCellValue))
          case _ => {
            val cellValue: Cell => Any = (cell: Cell) => {
              cell.getCellTypeEnum match {
                case number if number == CellType.NUMERIC =>
                  cell.getNumericCellValue
                case yesNo if yesNo == CellType.BOOLEAN =>
                  cell.getBooleanCellValue
                case text if text == CellType.STRING => cell.getStringCellValue
                case _                               => ""
              }
            }
            val index = cell.getColumnIndex
//            println(s"cell index is $index")
            val content = cellValue(cell)
            if (!content.equals("")) {
              fieldTypes(size - index) match {
                case "Input" =>
                  input = input.+(
                    (fieldLabels(size - index), String.valueOf(content))
                  )
                case "Output" =>
                  output = output.+(
                    (fieldLabels(size - index), String.valueOf(content))
                  )
              }
            }
          }
        }
      })
      if (input.nonEmpty) {
        val now = new Date()
        val timeObj = Map("$date" -> now)
        val config = Map(
          "_id" -> Map("$oid" -> new ObjectId().toHexString),
          "is_active" -> true,
          "paramCount" -> input.size,
          "isDeleted" -> false,
          "version" -> 1,
          "published_at" -> timeObj,
          "created_at" -> timeObj,
          "last_modified_at" -> timeObj,
          "published_note" -> "Migrated",
          "last_modified_by" -> "Admin",
          "parameters" -> input,
          "settings" -> output
//          "counter" -> row.getRowNum
        )
        configs = configs :+ config
      }
//      println(input)
//      println(output)

//      println(s"field types $fieldTypes length ${fieldTypes.size}")
//      println(s"field input types $fieldInputTypes")
//      println(s"field labels $fieldLabels")
//      println(s"$i ends ========")
//      i = i + 1
    })
    val data = write(configs)
    val fileOut = new File(getClass.getResource("/output.json").getPath)
    println(fileOut.getPath)
//    println(data)
    val printWriter = new PrintWriter(fileOut)
    printWriter.write(data)
    printWriter.close()

  }

}

object Converter extends App {

  val obj = new Converter()
  obj.read

  def toCamel(s: String): String = {
    val split = s.toLowerCase.split(" ")
    val tail = split.tail.map { x =>
      x.head.toUpper + x.tail
    }
    split.head + tail.mkString
  }

}
