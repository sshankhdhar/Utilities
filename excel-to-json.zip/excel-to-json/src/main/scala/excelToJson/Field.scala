package excelToJson

case class Field(label: String, dataType: String, values: Seq[String])
